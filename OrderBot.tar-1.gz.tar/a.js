const mongoose = require('mongoose');

const Schema = mongoose.Schema({
  code: String,
  checked: Boolean
});

module.exports = mongoose.model('weekly', Schema);
const mongoose = require('mongoose');

const Schema = mongoose.Schema({
  guildId: String,
  channel: String
});

module.exports = mongoose.model('channels', Schema);
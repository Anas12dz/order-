async function globalCmd(client) {
    const data = [
      {
        name: "set_time",
        description: "set time for close and open to the rooms"
      },
      {
      name: "add_channel",
            description: "add channel to auto close and open",
            options: [
                {
                    name: "channel",
                    description: "channel that will be changed occured to status",
                    type: 7,
                    required: "true"
                },
        ]
      },
      {
      name: "channel_list",
      description: "list of all channels that will be changed",
      },
      {
      name: "mnshor",
      description: "create a special mnshor",
        options: [
          {
            name: "mnshor",
            description: "almnshor",
            type: 3,
            required: "true"
          }
        ]
      },
      {
      name: "check_role",
            description: "check role users",
            options: [
                {
                    name: "role",
                    description: "role to get its users",
                    type: 8,
                    required: "true"
                },
        ]
      },
      {
        name: "embed",
        description: "creates an embed"
      },
      ]
	await client.application?.commands.set(data)
}

module.exports = { globalCmd }
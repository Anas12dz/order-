const axios = require("axios")
const express = require("express")
const app = express()
app.listen(2035)
let mnshorid = ""// ايدي شات المنشورات 
const wait = require('util').promisify(setTimeout);
process.on("unhandledRejection", error => {
  return console.log(error)
});
const moment = require("moment")
const ms = require("ms")
const fetchAll = require('discord-fetch-all');
const prefix = "-"
const owenner = "" // ايدي مالتك
const supportid = ""// ايدي رتبه السبورت
const idrole = "" //ايدي رتبه الإشعارات الطلبات
const orderc = require("./orderCooldown.js")
const line = "https://media.discordapp.net/attachments/1078637928965750844/1211259035018596372/ccc.png?ex=661275e2&is=660000e2&hm=9b90705ce224a87c943aa7e08afdd5994d60f8e64cdc437b334b0dd8b7401649&" // رابط الخط
const {
  AudioPlayer,
  AudioPlayerError,
  AudioPlayerStatus,
  AudioReceiveStream,
  AudioResource,
  EndBehaviorType,
  NoSubscriberBehavior,
  PlayerSubscription,
  SSRCMap,
  SpeakingMap,
  StreamType,
  VoiceConnection,
  VoiceConnectionDisconnectReason,
  VoiceConnectionStatus,
  VoiceReceiver,
  createAudioPlayer,
  createAudioResource,
  createDefaultAudioReceiveStreamOptions,
  demuxProbe,
  entersState,
  generateDependencyReport,
  getGroups,
  getVoiceConnection,
  getVoiceConnections,
  joinVoiceChannel,
  validateDiscordOpusHead
} = require('@discordjs/voice');
const {
  Client,
  Util,
  Collection,
  MessageEmbed,
  GatewayIntentBits,
  ButtonBuilder,
  EmbedBuilder,
  MessageSelectMenu,
  Partials,
  ApplicationCommandType,
  ApplicationCommandOptionType,
  InteractionType,
  ModalBuilder,
  ActivityType,
  ActivityFlags,
  ActivityPlatform,
  PermissionFlagsBits,
  Permissions,
  ActionRowBuilder,
  TextInputBuilder,
  PermissionsBitField,
  ChannelType,
  TextInputStyle
} = require("discord.js");
const client = new Client({
  partials: Object.values(Partials),
  intents: Object.values(GatewayIntentBits),
  allowedMentions: { parse: ["users", "roles", "everyone"], repliedUser: false },
});


// صاحب البروجكيت (pro_de) ()


const mongoose = require('mongoose')
const connectDB = async () => {
  await mongoose.connect("mongodb+srv://prode112:prode112@cluster0.di619gc.mongodb.net/?retryWrites=true&w=majority", {
    useUnifiedTopology: true,
    useNewUrlParser: true,
}).catch(function (error) {
          console.log(`Unable to connect to the Mongo db  ${error} `);
      });
};       
connectDB();
mongoose.connection.on('connected', function () {  
  console.log('Mongoose is connected');
});


const { globalCmd } = require("./dataHandler")
const colorsarray = require("./colors.json")


//console.log(colors)

function match ({title, category}) {
let array = []
 category.map(data => {
  let name = data.name.toLowerCase()
  if(name.includes(title) === true) array.push(data)
})
return array[0]
}
const countryZone = require("./countrysZone.json").countries
function calcTime(country) {
let data = match({title: country, category: countryZone})
  if(!data) return "Not a valid country"
const d = new Date();
const localTime = d.getTime();
const localOffset = d.getTimezoneOffset() * 60000;

const utc = localTime + localOffset;
const offset = data.timezone_offset;
const countryT = utc + (3600000 * offset);
 var weekdays = new Array(7);
        weekdays[0] = "Sunday";
        weekdays[1] = "Monday";
        weekdays[2] = "Tuesday";
        weekdays[3] = "Wednesday";
        weekdays[4] = "Thursday";
        weekdays[5] = "Friday";
        weekdays[6] = "Saturday";
const countryTime = new Date(countryT).toLocaleString();
  let date = new Date(countryT)
  date = date.getDay()
  let currentTimeee = countryTime.split(" ")[1]
  //console.log(currentTimeee)
  return ({time: currentTimeee, offset: offset, time2: new Date(countryT).toLocaleString(), day: weekdays[date]})
}

function getColor(color) {
  let data = match({title: color, category: colorsarray})

    if(!data) return "Not a valid color"
  let colorr = data.hex
  colorr = colorr.split("#").join("0x")
  return `${colorr}`
}

client.on("ready", async () => {
  console.log(`${client.user.tag} is online`)
  client.user.setPresence({ activities: [{ name: `pro_de / owner`, type: ActivityType.Playing }], status: 'online' })
  globalCmd(client)
})







client.on('interactionCreate', async interaction => {
  if (!interaction.isCommand() || !interaction.guild.id) return
  if (interaction.commandName === "set_time") {
         if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) return;

    const modal = new ModalBuilder()
      .setCustomId('setTime')
      .setTitle('تسطيب مواعيد الغلق والفتح');
    const opentime = new TextInputBuilder()
      .setCustomId('openTime')
      .setLabel("إدخل وقت الفتح مثال 06:00")
      .setStyle(TextInputStyle.Short);

    const firstActionRow = new ActionRowBuilder().addComponents(opentime);

    const closetime = new TextInputBuilder()
      .setCustomId('closeTime')
      .setLabel("إدخل وقت الغلق مثال 22:00")
      .setStyle(TextInputStyle.Short);

    const secondActionRow = new ActionRowBuilder().addComponents(closetime);

    const country = new TextInputBuilder()
      .setCustomId('country')
      .setLabel("ادخل الدولة مثال: Iraq")
      .setStyle(TextInputStyle.Short);

    const second2ActionRow = new ActionRowBuilder().addComponents(country);

    const channel = new TextInputBuilder()
      .setCustomId('channel')
      .setLabel("إدخل ايدي الروم الي بينرسل فيها رساله")
      .setStyle(TextInputStyle.Short);

    const second3ActionRow = new ActionRowBuilder().addComponents(channel);

    modal.addComponents(firstActionRow, secondActionRow, second2ActionRow, second3ActionRow);

    await interaction.showModal(modal);
}
})
let timeData = require("./timeData.js")
const channelD = require("./channelData")

client.on('interactionCreate', async interaction => {
  if (interaction.type !== InteractionType.ModalSubmit) return;
  if (interaction.customId === 'setTime') {
     if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) return;

    let openTime = interaction.fields.getTextInputValue('openTime');
    let closeTime = interaction.fields.getTextInputValue('closeTime');
    let country = interaction.fields.getTextInputValue('country');
    let channel = interaction.fields.getTextInputValue('channel');
    if(!interaction.guild.channels.cache.get(channel)) return interaction.reply(`Please type a valid channel id`)
    let gmt = await calcTime(country)
    gmt = gmt.offset



    let d = await timeData.findOne({guildId: interaction.guild.id})
    if(d) {
      d.openTime = openTime
      d.closeTime = closeTime
      d.country = country
      d.gmt = gmt
      d.channel = channel
      d.status = "none"
      await d.save()
          await interaction.reply(`Data has been edited`)

    } else {
      timeData.create({
        guildId: interaction.guild.id,
        openTime: openTime,
        closeTime: closeTime,
        country: country, 
        gmt: gmt,
        status: "none",
        channel: channel
      })
          await interaction.reply(`Data has been created`)
    }
}
})

function unfancyTimeFormat(hms) {
  let hmss = hms.split(":")
  if(hmss.length >= 4) {
const [days, hours, minutes, seconds] = hms.split(':');
const totalSeconds = (+days) * 24 * 60 * 60 +(+hours) * 60 * 60 + (+minutes) * 60 + (+seconds);
    return totalSeconds
  } else if(hmss.length <= 4 && hmss.length > 2) {
    const [hours, minutes, seconds] = hms.split(':');
    return (+hours) * 60 * 60 + (+minutes) * 60 + (+seconds);
  } else if(hmss.length === 2) {
        const [minutes, seconds] = hms.split(':');
    return (+minutes) * 60 + (+seconds);
  } else if(hmss.length < 2) {
    return hms
  }
}


client.on("ready", async () => {
  setInterval(async () => {
        let channels = await channelD.find()
  let da = await timeData.find()
    if(!da) return;
  da.forEach(async data => {
    let country = data.country
    let openFormat = data.openTime + ":00"
    let closeFormat = data.closeTime + ":00"
    let openTime = unfancyTimeFormat(openFormat)
    let currentTimeee = await calcTime(data.country).time

    currentTimeee = moment(currentTimeee, 'hh:mm:ss A').format('HH:mm:ss')

    let currentTime = unfancyTimeFormat(currentTimeee)
    let closeTime = unfancyTimeFormat(closeFormat)
    let guild = await client.guilds.cache.get(data.guildId)
    let channel = await guild.channels.cache.get(data.channel)
    let everyone = guild.roles.cache.find(pro_de => pro_de.name === '@everyone')
    
    if(openTime < currentTime) {
      if(currentTime < closeTime) {
        if(data.status === "close" || data.status === "none") {
      data.status = "open"
      data.save()
      channels.forEach(async c => {
        let b = await guild.channels.cache.get(c.channel)
        if(!b) return;
        await b.permissionOverwrites.edit(everyone, { ViewChannel: true })
      })
      if(channel) await channel.send(`تم فتح الرومات @everyone`)

      }
      } else if(closeTime < currentTime) {
      if(data.status === "open" || data.status === "none") {
      data.status = "close"
      data.save()
            if(channel) await channel.send(`تم غلق الرومات @everyone`)

      channels.forEach(async c => {
        let b = await guild.channels.cache.get(c.channel)
        if(!b) return;
        await b.permissionOverwrites.edit(everyone, { ViewChannel: false })

        const allMessages = await fetchAll.messages(b, {
    reverseArray: false, 
    userOnly: false, 
    botOnly: false, 
    pinnedOnly: false,
})
        allMessages.forEach(async m => {
          await m.delete()
        })
      })
      }
    }
    }
  })
  }, 3000)
})





client.on('interactionCreate', async interaction => {
  if (!interaction.isCommand() || !interaction.guild.id) return
  if (interaction.commandName === "add_channel") {
          if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) return;

    let channel = interaction.options.getChannel("channel")
    let data = await channelD.findOne({guildId: interaction.guild.id, channel: channel.id})
    if(data) {
      await data.delete()
      await interaction.reply(`${channel} Has been removed`)
    } else {
      channelD.create({
        guildId: interaction.guild.id,
        channel: channel.id
      })
      await interaction.reply(`${channel} Has been added`)
    }
  }
})



client.on('interactionCreate', async interaction => {
  if (!interaction.isCommand() || !interaction.guild.id) return
  if (interaction.commandName === "channel_list") {
      if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) return;
    let data = await channelD.find()
    let m = ""
    if(!data) return interaction.reply(`There is no channel added`)
    if(data.length === 0) return interaction.reply(`There is no channel added`)
    let n = 0
    data.forEach(d => {
      n++
      m += `**#${n}** <#${d.channel}>\n`
    })

    const embed = new EmbedBuilder()
    .setDescription(`**Channels:**\n\n${m}`)
    await interaction.reply({embeds: [embed]})
  }
})





let pointss = require("./points.js")
client.on("channelCreate", async(channel) => {
  if(channel.name.startsWith("ticket-")) {
    await wait(1000)
    let claim = new EmbedBuilder()
    .setDescription(`**اضغط على الزر لاستلام التكت**`)
    .setColor(`71368a`)
      const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('getp')
                    .setLabel('Claim Ticket')
                    .setStyle('Success')
              )
    await channel.send({embeds: [claim],components: [row]})
  }
})
client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;
  if (interaction.customId === 'getp') {
      
      if(!interaction.member.roles.cache.has(`${supportid}`)) return;

    let claimed = new EmbedBuilder()
    .setDescription(`**تم استلام التكت بواسطه: ${interaction.user}**`)
            const row = new ActionRowBuilder()
                 .addComponents(
                new ButtonBuilder()
                    .setCustomId('pcollected')
                    .setLabel('Ticket Claimed') 
                    .setStyle(1)
                    .setDisabled()
              )
await interaction.message.edit({embeds: [claimed],components: [row]})

    await interaction.deferUpdate()
    let data = await pointss.findOne({userId: interaction.user.id, guildId: interaction.guild.id})
    if(data) {
      data.points = data.points + 1
      data.week = data.week + 1
      await data.save()
    } else {
      pointss.create({
        guildId: interaction.guild.id,
        userId: interaction.user.id,
        points: 1,
        week : 1
      })
    }
    }
})


client.on("messageCreate", async message =>{
if(message.content.startsWith(prefix + 'top')){
if (!message.channel.guild) return ;
  if(!message.member.roles.cache.has(`${supportid}`)) return;
  let data = await pointss.find({guildId: message.guild.id})
  if(!data) return message.reply(`There are no points`)
  if(!data.length) return message.reply(`There are no points`)
let raank = await data.sort((a,b) => b.points-a.points).findIndex(m=> m.userId === message.author.id) + 1
  let news = await data.sort((a,b) => b.points-a.points)
  let hhh = await pointss.findOne({userId: message.author.id})
  if(!hhh) hhh = 0
let array =[]
for(let i=0; i <=9; i++){
if(news[i] === undefined ) continue;
array.push(news[i])
}
    let test = await array.map((c,i) => `**#${++i} I **<@!${c.userId}> **[\`\`${c.points}\`\`] (${c.week})**`)
    let final = test.join("\n")
    const embed = new EmbedBuilder()
    .setAuthor({ name: `Top Server Points:`, iconURL: message.guild.iconURL() })
    .setThumbnail(client.user.avatarURL({ }))
    .setColor(`71368a`)
    .setDescription(final)
    .addFields({name: `━━━━━━━━━━━━━━━━`,value: `**#${raank} | ${message.author} [\`\`${hhh.points}\`\`] (${hhh.week})**`})
    .setFooter({text: `${message.guild.name}`, iconURL: `${client.user.avatarURL({ }),message.author.displayAvatarURL({})}`})
    .setTimestamp()
    await message.reply({embeds: [embed], components: [], content: ` `})
}
})

client.on("messageCreate", async message =>{
if(message.content.startsWith(prefix + 'points')){
if (!message.channel.guild) return ;
  if(!message.member.roles.cache.has(`${supportid}`)) return;
  let data = await pointss.find({guildId: message.guild.id})
if(!data) return message.reply(`You don't have points`)
  if(!data.length) return message.reply(`You don't have points`)
    let raank = await data.sort((a,b) => b.points-a.points).findIndex(m=> m.userId === message.author.id) + 1
  let news = await data.sort((a,b) => b.points-a.points)
  let hhh = await pointss.findOne({userId: message.author.id})
  if(!hhh) hhh = 0
let array =[]
for(let i=0; i <=9; i++){
if(news[i] === undefined ) continue;
array.push(news[i])
}


    const embed = new EmbedBuilder()
    .setAuthor({ name: `Rank/Points`, iconURL: message.guild.iconURL() })
    .setThumbnail(client.user.avatarURL({ }))
    .setColor(`71368a`)
    .addFields({name: `Your rank/points is:`,value: `**#${raank} | ${message.author} [\`\`${hhh.points}\`\`]**`})

    .setFooter({text: `. ${message.guild.name}`, iconURL: `${client.user.avatarURL({ }),message.author.displayAvatarURL({})}`})
    .setTimestamp()
    await message.reply({embeds: [embed], components: [], content: ` `})
}
})

client.on("messageCreate", async message =>{
if(message.content.startsWith(prefix + 'reset')){
if (!message.channel.guild) return ;
  if(message.author.id !== owenner) return;
  let data = await pointss.find({guildId: message.guild.id})
  data.forEach(async d => {
    await d.delete()
    message.reply(`done reset the points`)
  })
}
})
function justNumber(string) {
  var numsStr = string.replace(/[^0-9]/g, '');
  return parseInt(numsStr);
}
client.on("messageCreate", async message =>{
if(message.content.startsWith(prefix + 'add-points')){
if (!message.channel.guild) return ;
  if(message.author.id !== owenner) return;
  let test = message.content.split(" ")
  let userId = test[1]
  if(!userId) return message.reply(`type user id first`)
  let countt = test[2]
    if(!countt) return message.reply(`type user id first`)
  let count = justNumber(countt)
  let data = await pointss.findOne({guildId: message.guild.id, userId: userId})
  if(data) {
    data.points = count
    await data.save()
    await message.reply(`points added`)
  } else {
    let user = await client.users.cache.get(userId)
    if(!user) return message.reply("type valid user")
    await pointss.create({
      guildId: message.guild.id,
      userId: userId,
      points: count,
      week: count,
    })
        await message.reply(`points added`)

  }
}
})



client.on('interactionCreate', async interaction => {
  if (!interaction.isCommand() || !interaction.guild.id) return
  if (interaction.commandName === "mnshor") {
         if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) return;
    let message = interaction.options.getString("mnshor")
    let row = new ActionRowBuilder().addComponents(
       new ButtonBuilder()
      .setCustomId('here')
      .setLabel(`Here`)
      .setStyle(`Secondary`),
      new ButtonBuilder()
      .setCustomId('everyone')
      .setLabel(`Everyone`)
      .setStyle(`Danger`)
    )
    await interaction.reply({content: `${message}`, components: [row]})
  }
})

client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;
  if (interaction.customId === 'here') {
              if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) return;

    let channel = await interaction.guild.channels.cache.get(mnshorid)
    if(!channel) return interaction.reply({content: `شات المنشورات غير مجدد.`, ephemeral: true})
    await channel.send(`${interaction.message.content}\n\n> Sent By: ${interaction.user} - @here`)
    await interaction.message.delete()
  }
})


client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;
  if (interaction.customId === 'everyone') {
              if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) return;

    let channel = await interaction.guild.channels.cache.get(mnshorid)
    if(!channel) return interaction.reply({content: `شات المنشورات غير مجدد.`, ephemeral: true})
    await channel.send(`${interaction.message.content}\n\n> Sent By: ${interaction.user} - @everyone`)
        await interaction.message.delete()

  }
})


client.on("messageCreate", async message => {
    if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) return;
  if(message.content === "خط") {
    message.channel.send({ files: [line]})
    message.delete()
  }
})
client.on("messageCreate", async message => {
  if(message.content === prefix + "resend-order") {
    let embed = new EmbedBuilder()
    .setTitle(`Orders`)
    .setDescription(`لو حاب تطلب منتج تقدر تضغط علي نوع\nالطلب الي تبيه وبيظهر لك قائمة اكتب فيها طلبك`)
    .setTimestamp()

let row = new ActionRowBuilder().addComponents(
       new ButtonBuilder()
      .setCustomId('dev')
      .setLabel(`برمجه`)
      .setEmoji("👩‍💻")
      .setStyle(`Primary`),
      new ButtonBuilder()
      .setCustomId('des')
      .setLabel(`تصميم`)
        .setEmoji("🖌")
      .setStyle(`Primary`),
  new ButtonBuilder()
      .setCustomId('item')
      .setLabel(`منتج`)
          .setEmoji("🎮")
      .setStyle(`Primary`)
    )

   message.channel.send({embeds: [embed], components: [row]})
  }
})



client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;
  if (interaction.customId === 'dev') {
    const modal = new ModalBuilder()
      .setCustomId('devorder')
      .setTitle(`Dev Orders`);
      
    const opentime = new TextInputBuilder()
      .setCustomId('devuserorder')
      .setLabel("إكتب طلبك")
      .setStyle(TextInputStyle.Paragraph);

    const firstActionRow = new ActionRowBuilder().addComponents(opentime);

  modal.addComponents(firstActionRow);

    await interaction.showModal(modal);
  }
})

client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;
  if (interaction.customId === 'des') {
    const modal = new ModalBuilder()
      .setCustomId('desorder')
      .setTitle(`Design Orders`);
    const opentime = new TextInputBuilder()
      .setCustomId('desuserorder')
      .setLabel("إكتب طلبك")
      .setStyle(TextInputStyle.Paragraph);

    const firstActionRow = new ActionRowBuilder().addComponents(opentime);


  modal.addComponents(firstActionRow);
      
    await interaction.showModal(modal);
  }
})

client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;
  if (interaction.customId === 'item') {
    const modal = new ModalBuilder()
      .setCustomId('itemorder')
      .setTitle(`Other Orders`);
    const opentime = new TextInputBuilder()
      .setCustomId('itemuserorder')
      .setLabel("إكتب طلبك")
      .setStyle(TextInputStyle.Paragraph);

    const firstActionRow = new ActionRowBuilder().addComponents(opentime);


  modal.addComponents(firstActionRow);

    await interaction.showModal(modal);
  }
})


client.on('interactionCreate', async interaction => {
  if (interaction.type !== InteractionType.ModalSubmit) return;
  if (interaction.customId === 'itemorder') {

    let data = await orderc.findOne({userId: interaction.user.id})
    if(data) {
      let timeout = ms(`${data.time}`)
    let time = ms(timeout - (Date.now() - data.coolDown), { verbose: true });
          let s = Math.floor(ms(time) / 1000)
              let time2 = Math.round((Date.now() + s * 1000) / 1000)
      return interaction.reply({content: `You can send other order <t:${time2}:R> `, ephemeral: true})
    } 
    let order = interaction.fields.getTextInputValue('itemuserorder')
    let channel = interaction.guild.channels.cache.get("")
    if(!channel) return interaction.reply({content: `شات هذاه للطلبات غير محدده`, ephemeral: true})

    let embed = new EmbedBuilder()
    .setAuthor({ name: `New order`, iconURL: interaction.user.avatarURL({ }) })
    .setDescription(`**[${interaction.user.username}](https://discord.com/users/${interaction.user.id})**\n${order}`)
    .setTimestamp()
    .setColor(`#00ACFF`)
let row = new ActionRowBuilder().addComponents(
       new ButtonBuilder()
      .setCustomId('deleteorder')
      .setLabel(`Delete`)
      .setEmoji("🚫")
      .setStyle(`Danger`),
  )
    await channel.send({embeds: [embed], components: [row], content: `<@&${idrole}>`})
    await interaction.reply({content: `Order has been created`, ephemeral: true})
    channel.send({ files:[line] })
    await orderc.create({
      userId: interaction.user.id,
      time: "1h",
      coolDown: Date.now(),
      guildId: interaction.guild.id
    })
  }
})


client.on('interactionCreate', async interaction => {
  if (interaction.type !== InteractionType.ModalSubmit) return;
  if (interaction.customId === 'devorder') {
let data = await orderc.findOne({userId: interaction.user.id})
    if(data) {
      let timeout = ms(`${data.time}`)
    let time = ms(timeout - (Date.now() - data.coolDown), { verbose: true });
          let s = Math.floor(ms(time) / 1000)
              let time2 = Math.round((Date.now() + s * 1000) / 1000)
      return interaction.reply({content: `You can send other order <t:${time2}:R> `, ephemeral: true})
    } 
    let order = interaction.fields.getTextInputValue('devuserorder')
    let channel = interaction.guild.channels.cache.get("")
    if(!channel) return interaction.reply({content: `شات هذاه للطلبات غير محدده`, ephemeral: true})
    let embed = new EmbedBuilder()
    .setAuthor({ name: `New order`, iconURL: interaction.user.avatarURL({ }) })
    .setDescription(`**[${interaction.user.username}](https://discord.com/users/${interaction.user.id})**\n${order}`)
    .setTimestamp()
let row = new ActionRowBuilder().addComponents(
       new ButtonBuilder()
      .setCustomId('deleteorder')
      .setLabel(`Delete`)
      .setEmoji("🚫")
      .setStyle(`Danger`),
  )
    await channel.send({embeds: [embed], components: [row], content: `<@&${idrole}>`})
    await interaction.reply({content: `Order has been created`, ephemeral: true})
      channel.send({ files:[line] })
    await orderc.create({
      userId: interaction.user.id,
      time: "1h",
      coolDown: Date.now(),
      guildId: interaction.guild.id
    })
  }
})


client.on('interactionCreate', async interaction => {
  if (interaction.type !== InteractionType.ModalSubmit) return;
  if (interaction.customId === 'desorder') {
let data = await orderc.findOne({userId: interaction.user.id})
    if(data) {
      let timeout = ms(`${data.time}`)
    let time = ms(timeout - (Date.now() - data.coolDown), { verbose: true });
          let s = Math.floor(ms(time) / 1000)
              let time2 = Math.round((Date.now() + s * 1000) / 1000)
      return interaction.reply({content: `You can send other order <t:${time2}:R> `, ephemeral: true})
    } 
    let order = interaction.fields.getTextInputValue('desuserorder')
    let channel = interaction.guild.channels.cache.get("")
    if(!channel) return interaction.reply({content: `شات هذاه للطلبات غير محدده`, ephemeral: true})
    let embed = new EmbedBuilder()
    .setAuthor({ name: `New order`, iconURL: interaction.user.avatarURL({ }) })
    .setDescription(`**[${interaction.user.username}](https://discord.com/users/${interaction.user.id})**\n${order}`)
    .setTimestamp()
let row = new ActionRowBuilder().addComponents(
       new ButtonBuilder()
      .setCustomId('deleteorder')
      .setLabel(`Delete`)
      .setEmoji("🚫")
      .setStyle(`Danger`),
  )
    await channel.send({embeds: [embed], components: [row], content: `<@&${idrole}>`})
    await interaction.reply({content: `Order has been created`, ephemeral: true})
       channel.send({ files:[line] })
    await orderc.create({
      userId: interaction.user.id,
      time: "1h",
      coolDown: Date.now(),
      guildId: interaction.guild.id
    })
  }
})


client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;
  if (interaction.customId === 'deleteorder') {
    if(!interaction.member.roles.cache.has(`${supportid}`)) return;
    await interaction.message.delete()
  }
})

client.on("ready", async ready => {
  setInterval(async () => {
    let dat = await orderc.find()
    dat.forEach(async data => {
      let timeout = ms(`${data.time}`)
      if (timeout - (Date.now() - data.coolDown) < 0) {
        await data.delete()
      }
    })
  }, 5000)
})

client.on('interactionCreate', async interaction => {
  if (!interaction.isCommand() || !interaction.guild.id) return
  if (interaction.commandName === "check_role") {
    await interaction.guild.members.fetch()
    if(!interaction.member.permissions.has(`ADMINISTRATOR`)) return;
    let role = interaction.options.getRole("role")
    let members = role.members.map(m=>m.user)

    let embed = new EmbedBuilder()
    .setDescription(`**${role.name} - ${role.members.size}**\n\n${members}`)
    .setTimestamp()
    await interaction.reply({embeds: [embed]})
  }
})

client.on('interactionCreate', async interaction => {
  if (!interaction.isCommand() || !interaction.guild.id) return
  if (interaction.commandName === "embed") {
    //await interaction.guild.members.fetch()
  if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) return;


    const modal = new ModalBuilder()
      .setCustomId('embed')
      .setTitle('creating an embed!');

    const title = new TextInputBuilder()
      .setCustomId('title')
        // The label is the prompt the user sees for this input
      .setLabel("Enter embed title (optional)")
        // Short means only a single line of text
      .setStyle(TextInputStyle.Short)
    .setMaxLength(20)
  // set the minimum number of characters required for submission
  //.setMinLength(2)
  // set a placeholder string to prompt the user
  .setPlaceholder('Enter some title!')
  // set a default value to pre-fill the input
  //.setValue('Default')
   // require a value in this input field
  .setRequired(false);

    const first3 = new ActionRowBuilder().addComponents(title)


    const description = new TextInputBuilder()
      .setCustomId('description')
        // The label is the prompt the user sees for this input
      .setLabel("Enter embed description")
        // Short means only a single line of text
      .setStyle(TextInputStyle.Paragraph)

    .setMaxLength(4000)
  // set the minimum number of characters required for submission
  .setMinLength(2)
  // set a placeholder string to prompt the user
  .setPlaceholder('Enter some description!')
  // set a default value to pre-fill the input
  //.setValue('Default')
   // require a value in this input field
  .setRequired(true);

    const first4 = new ActionRowBuilder().addComponents(description);

    const image = new TextInputBuilder()
      .setMaxLength(100)
  // set the minimum number of characters required for submission
  //.setMinLength(2)
  // set a placeholder string to prompt the user
  .setPlaceholder('Enter some url!')
  // set a default value to pre-fill the input
  //.setValue('Default')
   // require a value in this input field
  .setRequired(false)
      .setCustomId('image')
        // The label is the prompt the user sees for this input
      .setLabel("Enter embed image url (optional)")
        // Short means only a single line of text
      .setStyle(TextInputStyle.Short);

    const first6 = new ActionRowBuilder().addComponents(image);


    const footer = new TextInputBuilder()
      .setCustomId('footer')
        // The label is the prompt the user sees for this input
      .setLabel("Enter embed footer text (optional)")
      .setStyle(TextInputStyle.Short)

    .setMaxLength(20)
  .setPlaceholder('Enter some footer!')
  .setRequired(false);

    const first7 = new ActionRowBuilder().addComponents(footer);
     const color = new TextInputBuilder()
      .setCustomId('color')
      .setLabel("Embed color name (optional)")
      .setStyle(TextInputStyle.Short)

  .setMaxLength(20)
  .setPlaceholder('Enter some color!')
  .setRequired(false);

    const first9 = new ActionRowBuilder().addComponents(color);
    modal.addComponents(first3, first4, first6, first9, first7);
    await interaction.showModal(modal);

  }
})



client.on('interactionCreate', async interaction => {
  if (interaction.type !== InteractionType.ModalSubmit) return;
  if (interaction.customId === 'embed') {
      if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) return;

        let title = interaction.fields.getTextInputValue('title')// ?? " "
            let color = interaction.fields.getTextInputValue('color');
            let description = interaction.fields.getTextInputValue('description')
            let footer = interaction.fields.getTextInputValue('footer')
            let image = interaction.fields.getTextInputValue('image')
    if(!color) color = "black"
    let colorr = getColor(color)
        console.log(colorr)

    if(colorr === "Not a valid color") colorr = 0x00fffe
const exampleEmbed = new EmbedBuilder()


  .setColor(`#00ACFF`)
  .setDescription(description)
  .setAuthor({name:`${interaction.guild.name}`, iconURL: interaction.guild.iconURL({dynamic: true})})

  .setFooter({text:`${interaction.guild.name}`, iconURL: interaction.guild.iconURL({dynamic: true})})
  .setTimestamp()
if(image) exampleEmbed.setImage(image)
if(title) exampleEmbed.setTitle(title)

interaction.channel.send({ embeds: [exampleEmbed] });
interaction.channel.send({files:[line]})

await interaction.reply(`embed sent`)


  }
})



let cha = require("./a.js")
setInterval(async () => {
let time = calcTime("iraq").day
  let data = await cha.findOne({code: "123"})
  let data2 = await pointss.find()
  if(data) {
    if(data.checked === false) {
      if(time === "Saturday") {
        data2.forEach(async a => {
          a.week = 0
          await a.save()
        })
          data.checked = true
          await data.save()
      }
    } else if(data.checked === true) {
      if(time !== "Saturday") {
        data.checked === false
      }
    }
  } else {
    cha.create({
      code: "123",
      checked:false
    })
  }
}, 10000)



client.login("")// توكن بوتك..
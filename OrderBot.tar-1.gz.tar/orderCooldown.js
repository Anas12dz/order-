const mongoose = require('mongoose');

const Schema = mongoose.Schema({
  guildId: String,
  userId: String,
  coolDown: Number, 
  time: String
});

module.exports = mongoose.model('order-cooldown', Schema);
const mongoose = require('mongoose')

let Schema = new mongoose.Schema({
  guildId: String,
  userId: String,
  points: Number,
  week: Number
})

module.exports = mongoose.model('points', Schema)
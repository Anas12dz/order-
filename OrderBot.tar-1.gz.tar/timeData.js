const mongoose = require('mongoose');

const Schema = mongoose.Schema({
    guildId: String,
    country: String,
    time: Number,
    openTime: String,
    closeTime: String,
    gmt: String,
    status: String,
  channel: String
});

module.exports = mongoose.model('times', Schema);